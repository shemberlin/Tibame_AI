import mywindow1
import wx
import codecs
import os

class myFrame(mywindow1.MyFrame1):
    def build(self, event):
        self.m_textCtrl1.SetValue("")
    def open(self, event):
        while True:
            fnpath=wx.FileSelector("請選擇要開啟的檔案",wildcard="文字檔案(*.txt)|*.txt",flags=wx.FD_OPEN)
            if len(fnpath)==0:
                break
            windows.SetTitle("記事本 - "+os.path.basename(fnpath))
            with codecs.open(fnpath,"r",encoding="utf8") as f:
                text=f.read() 
            self.m_textCtrl1.SetValue(text)
    def save(self, event):
        while True:
            fnpath=wx.FileSelector("請選擇要儲存的檔名",wildcard="文字檔案(*.txt)|*.txt",flags=wx.FD_SAVE)
            if len(fnpath)==0:
                break
            windows.SetTitle("記事本 - "+os.path.basename(fnpath))
            with  codecs.open(fnpath,"w",encoding="utf8") as f:
                text=self.m_textCtrl1.GetValue()
                f.write(text)          
    def exit(self, event):
        wx.Exit()
    def aboutevent( self, event ):
        dialogwindows2=mywindow1.MyDialog3(None)
        dialogwindows2.SetSize(332,100)
        dialogwindows2.SetTitle("關於作者")
        dialogwindows2.m_staticText1.SetLabel("作者 : 林鉉博\n信箱 : roy.hsuanpolin@gmail.com\n網站 : https://www.linkedin.com/in/roy-lin-aa8baa184/")
        dialogwindows2.Show()

app=wx.App()
windows=myFrame(None)
windows.SetTitle("記事本")
windows.Show()
# wx.MessageBox("123")
app.MainLoop()
